.css referenced directly in index.html
